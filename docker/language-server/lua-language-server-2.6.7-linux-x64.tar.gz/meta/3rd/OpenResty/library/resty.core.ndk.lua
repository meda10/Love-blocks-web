---@meta
local resty_core_ndk={}
resty_core_ndk.version = require("resty.core.base").version
return resty_core_ndk