---@meta

--- Create a new table.
---
---@param narr integer number of array-like items
---@param nrec integer number of hash-like items
---@return table
local function new(narr, nrec) end

return new