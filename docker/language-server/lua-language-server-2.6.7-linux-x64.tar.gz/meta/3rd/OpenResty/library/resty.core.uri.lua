---@meta
local resty_core_uri={}
resty_core_uri.version = require("resty.core.base").version
return resty_core_uri