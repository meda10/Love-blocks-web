---@meta

--- Clear a table of its contents.
---@param t table
local function clear(t) end

return clear