---@meta

---@class cc.EaseCircleActionInOut :cc.ActionEase
local EaseCircleActionInOut={ }
cc.EaseCircleActionInOut=EaseCircleActionInOut




---* 
---@param action cc.ActionInterval
---@return self
function EaseCircleActionInOut:create (action) end
---* 
---@return self
function EaseCircleActionInOut:clone () end
---* 
---@param time float
---@return self
function EaseCircleActionInOut:update (time) end
---* 
---@return cc.ActionEase
function EaseCircleActionInOut:reverse () end
---* 
---@return self
function EaseCircleActionInOut:EaseCircleActionInOut () end