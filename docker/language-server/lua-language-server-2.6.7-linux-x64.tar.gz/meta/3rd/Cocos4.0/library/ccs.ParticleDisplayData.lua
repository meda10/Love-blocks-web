---@meta

---@class ccs.ParticleDisplayData :ccs.DisplayData
local ParticleDisplayData={ }
ccs.ParticleDisplayData=ParticleDisplayData




---* 
---@return self
function ParticleDisplayData:create () end
---* js ctor
---@return self
function ParticleDisplayData:ParticleDisplayData () end